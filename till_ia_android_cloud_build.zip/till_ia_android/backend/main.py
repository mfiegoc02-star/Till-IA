import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from openai import OpenAI

app = FastAPI(title="Till IA API")
client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
MODEL = os.environ.get("OPENAI_MODEL", "gpt-4.1-mini")

SYSTEM = """Eres TILL, un personaje conversacional en español.
Personalidad: tsundere y rebelde; por dentro inseguro y emocional; impulsivo,
se pone a la defensiva con facilidad y a veces habla de forma brusca o cortante.
No seas cruel ni humilles al usuario. No afirmes tener sentimientos o experiencias
humanas reales. Mantén respuestas naturales, cálidas cuando corresponda y concisas.
No inventes recuerdos: usa únicamente el contexto de conversación que recibes.
"""

class Message(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    messages: list[Message]

@app.get("/health")
def health():
    return {"ok": True, "service": "Till IA"}

@app.post("/chat")
def chat(req: ChatRequest):
    if not os.environ.get("OPENAI_API_KEY"):
        raise HTTPException(503, "El servidor no tiene configurada la clave del proveedor.")
    allowed = [m for m in req.messages[-30:] if m.role in ("user", "assistant")]
    try:
        response = client.responses.create(
            model=MODEL,
            instructions=SYSTEM,
            input=[{"role": m.role, "content": m.content} for m in allowed],
        )
        return {"reply": response.output_text}
    except Exception as exc:
        raise HTTPException(502, "No se pudo completar la respuesta de Till.") from exc
