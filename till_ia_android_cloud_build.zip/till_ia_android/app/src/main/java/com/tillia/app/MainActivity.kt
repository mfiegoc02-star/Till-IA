package com.tillia.app

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.time.temporal.ChronoUnit
import java.util.UUID

private val Bg = Color(0xFF090D12)
private val Panel = Color(0xFF171E26)
private val Teal = Color(0xFF20D6C2)
private val Gold = Color(0xFFE7C65B)
private val Muted = Color(0xFF9AA7B4)

data class ChatMessage(val role:String, val text:String, val time:Long=System.currentTimeMillis())

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TillApp(this) }
    }
}

@Composable
fun TillApp(ctx: Context) {
    val prefs = remember { ctx.getSharedPreferences("till", Context.MODE_PRIVATE) }
    var endpoint by remember { mutableStateOf(prefs.getString("endpoint", "https://TU-SERVIDOR/chat") ?: "") }
    var screen by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val history = remember {
        mutableStateListOf<ChatMessage>().apply {
            val arr = try { JSONArray(prefs.getString("history","[]")) } catch (_:Exception) { JSONArray() }
            val cutoff = System.currentTimeMillis() - 365L*24*60*60*1000
            for(i in 0 until arr.length()) {
                val o=arr.optJSONObject(i) ?: continue
                val t=o.optLong("time",0L)
                if(t>=cutoff) add(ChatMessage(o.optString("role"),o.optString("text"),t))
            }
        }
    }
    fun saveHistory() {
        val arr=JSONArray()
        history.forEach { m -> arr.put(JSONObject().put("role",m.role).put("text",m.text).put("time",m.time)) }
        prefs.edit().putString("history",arr.toString()).apply()
    }

    MaterialTheme(colorScheme=darkColorScheme(background=Bg, surface=Panel, primary=Teal, onPrimary=Bg, onBackground=Color.White)) {
        Surface(Modifier.fillMaxSize(), color=Bg) {
            if(!screen) {
                Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement=Arrangement.Center, horizontalAlignment=Alignment.CenterHorizontally) {
                    Text("till IA",fontSize=36.sp,fontWeight=FontWeight.Bold,color=Color.White)
                    Text("No estoy esperando. Solo estaba aquí.",color=Muted,fontSize=14.sp)
                    Spacer(Modifier.height(36.dp))
                    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Panel).clickable { screen=true }.padding(18.dp)) {
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Image(painterResource(R.drawable.till_avatar),null,Modifier.size(62.dp).clip(CircleShape), contentScale=ContentScale.Crop)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text("TILL",fontWeight=FontWeight.Bold,color=Color.White,fontSize=20.sp)
                                Text("Disponible · Chat de texto",color=Teal,fontSize=12.sp)
                            }
                            Text("●",color=Teal)
                        }
                    }
                    Spacer(Modifier.height(40.dp))
                    Text("●",color=Color(0xFFE34B59),modifier=Modifier.align(Alignment.Start).padding(start=18.dp))
                    Text("●",color=Color(0xFF46D68A),modifier=Modifier.align(Alignment.End).padding(end=30.dp))
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    Row(Modifier.fillMaxWidth().background(Panel).padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                        IconButton(onClick={screen=false}) { Icon(Icons.Default.ArrowBack,null,tint=Color.White) }
                        Image(painterResource(R.drawable.till_avatar),null,Modifier.size(42.dp).clip(CircleShape),contentScale=ContentScale.Crop)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("TILL IA",fontWeight=FontWeight.Bold,color=Color.White)
                            Text("● En línea",fontSize=11.sp,color=Teal)
                        }
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick={ screen=false }) { Text("Inicio",color=Gold) }
                    }
                    LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal=12.dp),reverseLayout=false,contentPadding=PaddingValues(vertical=14.dp)) {
                        items(history) { msg ->
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=if(msg.role=="user") Arrangement.End else Arrangement.Start) {
                                Box(Modifier.padding(vertical=4.dp).widthIn(max=310.dp).clip(RoundedCornerShape(17.dp))
                                    .background(if(msg.role=="user") Color(0xFF087F78) else Panel).padding(12.dp)) {
                                    Text(msg.text,color=Color.White,fontSize=15.sp)
                                }
                            }
                        }
                        if(busy) item { Text("Till está escribiendo…",color=Teal,modifier=Modifier.padding(8.dp)) }
                    }
                    if(error.isNotBlank()) Text(error,color=Color(0xFFFF8A80),fontSize=12.sp,modifier=Modifier.padding(horizontal=14.dp))
                    Row(Modifier.fillMaxWidth().background(Panel).padding(8.dp),verticalAlignment=Alignment.CenterVertically) {
                        OutlinedTextField(value=draft,onValueChange={draft=it},modifier=Modifier.weight(1f),placeholder={Text("Escribe un mensaje…",color=Muted)},shape=RoundedCornerShape(22.dp),maxLines=4)
                        IconButton(enabled=!busy && draft.isNotBlank(),onClick={
                            val text=draft.trim(); if(text.isNotEmpty()) {
                                draft=""; history.add(ChatMessage("user",text)); saveHistory(); error=""; busy=true
                                scope.launch {
                                    try {
                                        val reply=withContext(Dispatchers.IO) { askTill(endpoint,history.toList()) }
                                        history.add(ChatMessage("assistant",reply)); saveHistory()
                                    } catch(e:Exception) { error="No pude conectar con el servidor. Revisa la dirección y la conexión." }
                                    busy=false
                                }
                            }
                        }) { Icon(Icons.Default.Send,null,tint=Teal) }
                    }
                    Text("Tus conversaciones se guardan en este móvil durante aproximadamente un año.",color=Muted,fontSize=10.sp,modifier=Modifier.padding(8.dp))
                }
            }
        }
    }
}

fun askTill(endpoint:String, messages:List<ChatMessage>):String {
    if(endpoint.contains("TU-SERVIDOR")) throw IllegalStateException("Configura el servidor")
    val conn=URL(endpoint).openConnection() as HttpURLConnection
    conn.requestMethod="POST"; conn.connectTimeout=20000; conn.readTimeout=60000
    conn.doOutput=true; conn.setRequestProperty("Content-Type","application/json")
    val payload=JSONObject().put("messages",JSONArray().apply {
        messages.takeLast(30).forEach { put(JSONObject().put("role",it.role).put("content",it.text)) }
    })
    conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
    val code=conn.responseCode
    val stream=if(code in 200..299) conn.inputStream else conn.errorStream
    val body=stream.bufferedReader().use { it.readText() }; conn.disconnect()
    if(code !in 200..299) throw IllegalStateException("Server error $code")
    return JSONObject(body).optString("reply","No sé qué decir…")
}
