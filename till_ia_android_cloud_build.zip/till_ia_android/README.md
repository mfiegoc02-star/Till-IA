# till IA — proyecto Android inicial

Este ZIP contiene el **código fuente** de una primera versión nativa para Android, no un APK compilado.

## Qué incluye
- Pantalla de inicio con entrada al chat y puntos decorativos rojos/verdes.
- Chat de texto con avatar de Till y el icono de app elegido.
- Personalidad tsundere/rebelde definida en el servidor.
- Historial local en el móvil; la app conserva mensajes de hasta ~365 días y envía los últimos 30 al modelo.

## Lo que falta antes de instalarlo
1. Compilarlo con Android Studio en un ordenador.
2. Desplegar el backend de `backend/` en un servidor HTTPS.
3. Configurar `OPENAI_API_KEY` como variable secreta **solo en el servidor** (nunca dentro de la APK).
4. Cambiar el endpoint predeterminado `https://TU-SERVIDOR/chat` en `MainActivity.kt` por la URL HTTPS real.

La clave de API y el despliegue deben gestionarlos un adulto responsable. No publiques la clave ni la pegues en el código Android.

## Compilar
- Instala Android Studio y un JDK compatible con Android Gradle Plugin 8.7.
- Abre la carpeta `till_ia_android` en Android Studio.
- Espera a que Gradle sincronice y luego usa **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
- El APK de depuración aparecerá normalmente en `app/build/outputs/apk/debug/app-debug.apk`.

## Backend
En `backend/`, configura `OPENAI_API_KEY` en el entorno del servidor y ejecuta:
```bash
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```
Para uso real, publícalo detrás de HTTPS y añade autenticación, límites de uso y controles de abuso antes de compartirlo.

## Limitaciones conocidas de esta versión
- Es una base funcional inicial, no un producto terminado ni probado en un dispositivo.
- La memoria de un año es retención del historial local; todavía no existe extracción automática de recuerdos importantes ni un sistema gradual de olvido por relevancia.
- El historial no se sincroniza entre móviles.
- Sin servidor configurado, el chat no generará respuestas de IA.
